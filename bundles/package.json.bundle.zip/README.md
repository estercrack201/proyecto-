
  # SecurIT Técnico

  This is a code bundle for SecurIT Técnico. The original project is available at https://www.figma.com/design/L5FoqTNoMAqeONytmzx6YE/SecurIT-T%C3%A9cnico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  